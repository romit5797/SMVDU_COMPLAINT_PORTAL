<?php

require "conn.php";
 
 $name = $_POST['name'];
 $contact = $_POST['contact'];
  $room = $_POST['room'];
   $block = $_POST['block'];
    $hostel = $_POST['hostel'];
	 $category = $_POST['category'];
	 $email = $_POST['email'];
	 $details = $_POST['details'];
	 $status = "submitted";
	 $timestamp = date("Y-m-d H:i:s");

$today = date("Ymd");
$rand = strtoupper(substr(uniqid(sha1(time())),0,4));
$unique = $today . $rand;

 $Sql_Query = "insert into complaint (Name,C_number,Room,Block,Hostel,Category,email,Complaint,Status,Time,comp_no) values ('$name','$contact','$room','$block','$hostel','$category','$email','$details','$status','$timestamp','$unique')";
 
 if(mysqli_query($conn,$Sql_Query)){
 
 echo 'Data Submit Successfully';
 
 }
 else{
 
 echo 'Try Again';
 
 }
 mysqli_close($conn);
?>