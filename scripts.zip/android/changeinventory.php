<?php

require "conn.php";
 
 $net = $_POST['net'];
$consumed = $_POST['consumed']; 
$name= $_POST['name'];
 $timestamp = date("Y-m-d H:i:s");

 $Sql_Query = "UPDATE inventory SET Balance = $net,Issued = Issued+$consumed,Date='$timestamp' WHERE Name='$name'";
 
 if(mysqli_query($conn,$Sql_Query)){
 
 echo 'Data Submit Successfully';
 
 }
 else{
 
 echo 'Try Again';
 
 }
 mysqli_close($conn);
?>