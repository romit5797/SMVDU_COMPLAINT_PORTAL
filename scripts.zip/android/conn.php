<?php
$host = "localhost";
$user = "id9083748_romit";
$pass = "qwerty";
$db_name = "id9083748_9tutorials";

$conn = new mysqli($host,$user,$pass,$db_name);


?>