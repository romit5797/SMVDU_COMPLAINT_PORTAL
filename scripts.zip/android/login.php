
<?php 
require "conn.php";
$username = $_POST["username"];
$password = $_POST["password"];
$mysql_qry = "SELECT * FROM login WHERE email='$username' AND password='$password'";
$result = mysqli_query($conn ,$mysql_qry);
if(mysqli_num_rows($result) > 0) {
echo $username;
}
else {
echo "notsuccess";
}
 
?>