<?php

require "conn.php";

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
 
//if everything is fine
 
//creating an array for storing the data 
$heroes = array(); 
$comp_no = $_GET["comp_no"];
 
//this is our sql query 
$sql = "SELECT Category, comp_no, Complaint, Status, Time FROM complaint WHERE comp_no='$comp_no'";
 
//creating an statment with the query
$stmt = $conn->prepare($sql);
 
//executing that statment
$stmt->execute();
 
//binding results for that statment 
$stmt->bind_result($id, $tid, $sid , $pid, $name);
 
//looping through all the records
while($stmt->fetch()){
 
 //pushing fetched data in an array 
 $temp = [
 'id'=>$id,
 'tid'=>$tid,
 'sid'=>$sid,
 'pid'=>$pid,
 'name'=>$name
 ];
 
 //pushing the array inside the hero array 
 array_push($heroes, $temp);
}
 
//displaying the data in json format 
echo json_encode($heroes);

?>