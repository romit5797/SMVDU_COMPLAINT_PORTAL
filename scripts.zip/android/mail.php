<?php
require "conn.php";
    $email= $_POST["email"];
    $result = mysqli_query($conn,"SELECT * FROM login where email='$email'");
    $row = mysqli_fetch_assoc($result);
	$fetch_email=$row['email'];
	$password=$row['password'];
	if($email==$fetch_email) {
	    $to = $email;
	    $txt = "Your SMVDU COMPLAINT PORTAL password is : $password.";
		
$headers = 'From: php.mailing.test@gmail.com' . "\r\n" . 
           'MIME-Version: 1.0' . "\r\n" .
           'Content-Type: text/html; charset=utf-8';

$result = mail($to, "SMVDU COMPLAINT PORTAL PASSWORD",$txt, $headers);
}
var_dump($result);
				
