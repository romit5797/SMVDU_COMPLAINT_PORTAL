<?php

require "conn.php";
 
 $old = $_POST['old'];
$newp = $_POST['newp'];
	 $email = $_POST['email'];
	

 $Sql_Query = "UPDATE login SET password = '$newp' WHERE email='$email' AND password='$old'";
 
 if(mysqli_query($conn,$Sql_Query)){
 
 echo 'Data Submit Successfully';
 
 }
 else{
 
 echo 'Try Again';
 
 }
 mysqli_close($conn);
?>