
<?php 
require "conn.php";
$heroes = array(); 

$result = mysqli_query($conn,"select count(1) FROM complaint ");
$row = mysqli_fetch_array($result);

$total = $row[0];
$id = "Total Complaints: " . $total;


$result = mysqli_query($conn,"select count(1) FROM complaint WHERE Category='Internet' ");
$row = mysqli_fetch_array($result);

$total = $row[0];
$tid = "Internet related complaints: " . $total;


$result = mysqli_query($conn,"select count(1) FROM complaint WHERE Category='Electricity' ");
$row = mysqli_fetch_array($result);

$total = $row[0];
$sid = "Electricity related complaints: " . $total;


$result = mysqli_query($conn,"select count(1) FROM complaint WHERE Category='Others' ");
$row = mysqli_fetch_array($result);

$total = $row[0];
$name1 = "Other complaints: " . $total;

$result = mysqli_query($conn,"select count(1) FROM complaint WHERE Status='Resolved' ");
$row = mysqli_fetch_array($result);

$total = $row[0];
$name2 = "Total Resolved Complaints: " . $total;

$result = mysqli_query($conn,"select count(1) FROM complaint WHERE Status='Pending' ");
$row = mysqli_fetch_array($result);

$total = $row[0];
$name3 = "Total Pending Complaints: " . $total;

$result = mysqli_query($conn,"select count(1) FROM complaint WHERE Status='submitted' ");
$row = mysqli_fetch_array($result);

$total = $row[0];
$name4 = "Total Submitted Complaints: " . $total;


$result = mysqli_query($conn,"select count(1) FROM complaint WHERE Status='Resolved' AND Category='Internet' ");
$row = mysqli_fetch_array($result);

$total = $row[0];
$name5 = "Internet related Resolved Complaints: " . $total;

$result = mysqli_query($conn,"select count(1) FROM complaint WHERE Status='Pending' AND Category='Internet' ");
$row = mysqli_fetch_array($result);

$total = $row[0];
$name6 = "Internet related Pending Complaints: " . $total;

$result = mysqli_query($conn,"select count(1) FROM complaint WHERE Status='submitted' AND Category='Internet' ");
$row = mysqli_fetch_array($result);

$total = $row[0];
$name7 = "Internet related Submitted Complaints: " . $total;

$result = mysqli_query($conn,"select count(1) FROM complaint WHERE Status='Resolved' AND Category='Electricity' ");
$row = mysqli_fetch_array($result);

$total = $row[0];
$name8 = "Electricity related Resolved Complaints: " . $total;

$result = mysqli_query($conn,"select count(1) FROM complaint WHERE Status='Pending' AND Category='Electricity' ");
$row = mysqli_fetch_array($result);

$total = $row[0];
$name9 = "Electricity related Pending Complaints: " . $total;

$result = mysqli_query($conn,"select count(1) FROM complaint WHERE Status='submitted' AND Category='Electricity' ");
$row = mysqli_fetch_array($result);

$total = $row[0];
$name10 = "Electricity related Submitted Complaints: " . $total;

$result = mysqli_query($conn,"select count(1) FROM complaint WHERE Status='Resolved' AND Category='Other' ");
$row = mysqli_fetch_array($result);

$total = $row[0];
$name11 = "Other Resolved Complaints: " . $total;

$result = mysqli_query($conn,"select count(1) FROM complaint WHERE Status='Pending' AND Category='Other' ");
$row = mysqli_fetch_array($result);

$total = $row[0];
$name12 = "Other Pending Complaints: " . $total;

$result = mysqli_query($conn,"select count(1) FROM complaint WHERE Status='submitted' AND Category='Other' ");
$row = mysqli_fetch_array($result);

$total = $row[0];
$name= "Other Submitted Complaints: " . $total;

 $temp = [
 'id'=>$id,
 'tid'=>$tid,
 'sid'=>$sid,
 'name1'=>$name1,
 'name2'=>$name2,
 'name3'=>$name4,
 'name4'=>$name4,
  'name5'=>$name5,
   'name6'=>$name6,
    'name7'=>$name7,
	 'name8'=>$name8,
 'name9'=>$name9,
  'name10'=>$name10,
   'name11'=>$name11,
    'name12'=>$name12,
 'name'=>$name
 ];
 
 //pushing the array inside the hero array 
 array_push($heroes, $temp);

 
//displaying the data in json format 
echo json_encode($heroes);



mysqli_close($conn);
?>
 