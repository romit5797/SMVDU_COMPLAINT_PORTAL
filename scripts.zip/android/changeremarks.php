<?php

require "conn.php";
 
 $c_no = $_POST['c_no'];
$remarks = $_POST['remarks'];
	

 $Sql_Query = "UPDATE complaint SET REMARKS = '$remarks' WHERE comp_no='$c_no'";
 
 if(mysqli_query($conn,$Sql_Query)){
 
 echo 'Data Submit Successfully';
 
 }
 else{
 
 echo 'Try Again';
 
 }
 mysqli_close($conn);
?>