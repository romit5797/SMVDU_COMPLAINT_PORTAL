<?php

require "conn.php";
 
 $c_no = $_POST['c_no'];
$status = $_POST['status'];
	

 $Sql_Query = "UPDATE complaint SET Status = '$status' WHERE comp_no='$c_no'";
 
 if(mysqli_query($conn,$Sql_Query)){
 
 echo 'Data Submit Successfully';
 
 }
 else{
 
 echo 'Try Again';
 
 }
 mysqli_close($conn);
?>