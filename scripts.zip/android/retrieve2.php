<?php

require "conn.php";

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
 
//if everything is fine
 
//creating an array for storing the data 
$heroes = array();
$Category = $_GET["Category"]; 

 
//this is our sql query 
if($Category=="Administrator")
{
$sql = "SELECT Category, comp_no, Complaint, Status, Time, Remarks FROM complaint ";
$stmt = $conn->prepare($sql);
}
else if($Category == 'INTERNET_HEAD')
{
$sql = "SELECT Category, comp_no, Complaint, Status, Time, Remarks FROM complaint WHERE Category='Interent'";
$stmt = $conn->prepare($sql);
}
else if($Category== 'ELECTRICITY_HEAD')
{
$sql = "SELECT Category, comp_no, Complaint, Status, Time, Remarks FROM complaint WHERE Category='Electricity'";
$stmt = $conn->prepare($sql);
}
else if($Category == 'OTHERS')
{
$sql = "SELECT Category, comp_no, Complaint, Status, Time, Remarks FROM complaint WHERE Category='Other'";
$stmt = $conn->prepare($sql);
}

//creating an statment with the query

 
//executing that statment
$stmt->execute();
 
//binding results for that statment 
$stmt->bind_result($id, $tid, $sid , $pid, $aid, $name);
 
//looping through all the records
while($stmt->fetch()){
 
 //pushing fetched data in an array 
 $temp = [
 'id'=>$id,
 'tid'=>$tid,
 'sid'=>$sid,
 'pid'=>$pid, 
 'aid'=>$aid,
 'name'=>$name
 ];
 
 //pushing the array inside the hero array 
 array_push($heroes, $temp);
}
 
//displaying the data in json format 
echo json_encode($heroes);

?>